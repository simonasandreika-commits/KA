; Programa: didziuju raidziu skaiciavimas		; ";" - komentaras, kompiuteris jo neskaito
; Atliko: Vardas Pavarde				; ";" - komentaras

.model small			; programos dydis: kodas ir duomenys telpa po 64 KB (visada taip rasoma)
.stack 100h			; rezervuoti 256 baitus stekui (DOS'ui reikia, visada taip rasoma)

.data				; nuo cia prasideda kintamieji (duomenys)
	request	db 'Iveskite eilute:', 0Dh, 0Ah, '$'	; db - baitu seka; 0Dh,0Ah - nauja eilute; '$' - teksto pabaiga (be jo spausdintu siuksles)
	result	db 0Dh, 0Ah, 'Didziuju raidziu: $'	; pirma nauja eilute, tada tekstas, gale '$'
	buffer	db 100, ?, 100 dup (0)			; 100 - max simboliu; ? - cia DOS irasys kiek ivesta; 100 dup(0) - 100 nuliu, cia bus patys simboliai

.code				; nuo cia prasideda komandos

start:				; zyme (vardas vietai kode) - programos pradzia
	mov ax, @data		; mov a, b reiskia a = b; @data - adresas, kur atmintyje yra .data dalis
	mov ds, ax		; ds turi rodyti i duomenis; i ds negalima rasyti tiesiai, todel per ax

	mov ah, 09h			; ah = 09h - DOS funkcija "isvesti teksta, kurio adresas dx, iki '$'"
	mov dx, offset request		; offset request - teksto request adresas, dedam i dx
	int 21h				; iskviesti DOS - jis ziuri i ah ir isveda "Iveskite eilute:"

	mov ah, 0Ah			; ah = 0Ah - DOS funkcija "nuskaityti eilute is klaviaturos"
	mov dx, offset buffer		; i kuri buferi deti ivesta eilute
	int 21h				; laukia kol ivesi teksta ir paspausi Enter; buffer[1] = kiek ivesta, nuo buffer[2] - simboliai

	mov cl, buffer[1]		; cl = kiek simboliu ivesta (antras buferio baitas, skaiciuojam nuo 0)
	mov ch, 0			; cx = ch + cl; loop naudoja visa cx, todel ch isvalom
	mov si, offset buffer + 2	; si - rodykle; dabar rodo i pirma ivesta simboli
	mov bl, 0			; bl - didziuju raidziu skaitliukas, pradzioje 0

	cmp cx, 0			; cmp - palyginti cx su 0 (nieko nekeicia, tik palygina)
	je spausdinti			; je - sokti jei lygu; jei ivesta tik Enter, loop suktusi 65535 kartu, todel praleidziam

tikrinti:			; zyme - ciklo pradzia
	mov al, [si]			; [si] - reiksme adresu si; al = dabartinis simbolis
	cmp al, 'A'			; palyginti simboli su 'A' (ASCII 65)
	jb kitas			; jb - sokti jei maziau; tai ne didzioji raide (pvz. skaitmuo, tarpas)
	cmp al, 'Z'			; palyginti simboli su 'Z' (ASCII 90)
	ja kitas			; ja - sokti jei daugiau; tai ne didzioji raide (pvz. mazosios yra 97-122)
	inc bl				; inc - padidinti 1; simbolis tarp 'A' ir 'Z', t.y. didzioji raide
kitas:				; zyme - cia ateinam bet kuriuo atveju
	inc si				; si + 1 - dabar rodo i kita simboli
	loop tikrinti			; cx = cx - 1; jei cx dar ne 0 - sokti i tikrinti

spausdinti:			; zyme - rezultato isvedimas
	mov ah, 09h			; DOS funkcija "isvesti teksta"
	mov dx, offset result		; teksto result adresas
	int 21h				; isveda "Didziuju raidziu: "

	mov al, bl			; skaiciu is skaitliuko perkeliam i al
	mov ah, 0			; ah isvalom, kad ax = musu skaicius (div dalina visa ax)
	mov bl, 10			; dalinsim is 10 (bl galim perrasyti, skaicius jau al)
	div bl				; ax / bl: al = dalmuo (desimtys), ah = liekana (vienetai); pvz. 12 -> al=1, ah=2
	mov bh, ah			; vienetus issaugom bh, nes ah tuoj perrasysim

	mov ah, 2			; ah = 2 - DOS funkcija "isvesti viena simboli is dl"
	cmp al, 0			; ar yra desimciu?
	je vienetai			; jei nera - ju nespausdinam (kitaip vietoj 5 butu 05)
	mov dl, al			; desimtis dedam i dl
	add dl, '0'			; pridedam 48: skaicius 1 -> simbolis '1' (ASCII 49)
	int 21h				; isvedam desimciu skaitmeni
vienetai:			; zyme - vienetu isvedimas
	mov dl, bh			; vienetus (issaugotus bh) dedam i dl
	add dl, '0'			; paverciam skaiciu i simboli
	int 21h				; isvedam (ah vis dar = 2)

	mov ax, 4C00h			; ah = 4Ch - baigti programa, al = 00h - be klaidu
	int 21h				; DOS baigia programa (be sito DOSBox gali pakibti)

end start			; failo pabaiga; start - nuo kurios zymes pradedama vykdyti
