; Programa: didziuju raidziu skaiciavimas
; Atliko: Vardas Pavarde

.model small
.stack 100h

.data
	request	db 'Iveskite eilute:', 0Dh, 0Ah, '$'
	result	db 0Dh, 0Ah, 'Didziuju raidziu: $'
	buffer	db 100, ?, 100 dup (0)

.code

start:
	mov ax, @data
	mov ds, ax

	mov ah, 09h			; isvesti uzklausa
	mov dx, offset request
	int 21h

	mov ah, 0Ah			; nuskaityti eilute
	mov dx, offset buffer
	int 21h

	mov cl, buffer[1]		; kiek simboliu ivesta
	mov ch, 0
	mov si, offset buffer + 2	; pirmas simbolis
	mov bl, 0			; skaitliukas

	cmp cx, 0			; jei nieko neivesta
	je spausdinti

tikrinti:
	mov al, [si]
	cmp al, 'A'
	jb kitas			; mazesnis uz 'A' - ne didzioji
	cmp al, 'Z'
	ja kitas			; didesnis uz 'Z' - ne didzioji
	inc bl				; didzioji raide
kitas:
	inc si
	loop tikrinti

spausdinti:
	mov ah, 09h
	mov dx, offset result
	int 21h

	mov al, bl			; padalinti skaiciu is 10
	mov ah, 0
	mov bl, 10
	div bl				; al = desimtys, ah = vienetai
	mov bh, ah			; issaugoti vienetus

	mov ah, 2
	cmp al, 0			; jei desimciu nera, ju nespausdinti
	je vienetai
	mov dl, al
	add dl, '0'
	int 21h
vienetai:
	mov dl, bh
	add dl, '0'
	int 21h

	mov ax, 4C00h			; grizti i dos'a
	int 21h

end start
